<?
include('get/search.php');
include('get/keliling.php');
include('get/dataindex.php');
?>