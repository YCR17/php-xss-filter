let suggestions = [
  "keliling",
  "luas",
  "luas_permukaan",
  "volume",
  "pytagoras",
  "",
  "",
  "",
  "",
  "",
];