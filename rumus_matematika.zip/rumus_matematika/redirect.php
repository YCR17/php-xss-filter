<html>
<head>
  <script src="jquery-2.0.3.min.js"></script>
  <script>
    $(document).ready(function() {
      window.setInterval(function () {
        var sisawaktu = $("#waktu").html();
        sisawaktu = eval(sisawaktu);
        if (sisawaktu == 0) {
          location.href = "<?php echo $redirect ?>"
        } else {
          $("#waktu").html(sisawaktu - 1);
        }
      },
        1000);
    });
  </script>
  <style type="text/css">
    body {
      font-size: 12pt;
      font-family: verdana;
      background-color: white;
    }
    #waktu {
      font-size: 25pt;
      color: grey;
    }
  </style>
</head>
<body oncontextmenu="return false;" onkeydown="return false;" onmousedown="return false;">

  <center><br><br>

    <h3> mengalihkan anda ke :
      <hr size="6" color="silver">
      <span id="kemana">
        <?php echo $_POST['kemana'] ?>
      </span>
      <hr size="6" color="silver">
      dalam  <span id="waktu">10</span> detik</h3>
    <br><br>
    <div class="uwu">
      <br>

      <p style='margin: 0px 30px;'>
        <font color='#fff' size='5'>






          <hr size="6" color="silver"><br>

          <p style='margin: 0px 30px;'>
            <font color='#fff' size='4'> _ </font><font color='#fff' size='5'> WAIT A MOMENT... </font>
          </p>




          <hr size="6" color="silver"><br>

        </center>
      </font><br><br>
    </p>




  </body>
</html>