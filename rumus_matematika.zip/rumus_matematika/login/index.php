<?php
include('config.php');
if($_SESSION['admin']){
	$user_name = $_SESSION['admin'];
	$user_id = $_SESSION['admin_id'];
}elseif($_SESSION['user']){
	$user_name = $_SESSION['user'];
	$user_id = $_SESSION['user_id'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $row_brand['value']; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="<?php echo $row_favicon['value']; ?>">
    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo $row_brand['note']; ?>"><?php echo $row_brand['value']; ?></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<?php include('includes/menu.php'); ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Image Background Page Header -->
    <!-- Note: The background image is set within the business-casual.css file. -->
    <header class="business-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h1 class="tagline" style="padding-top: 80px">Upload and Share your files with everyone.</h1>
					<h3 class="tagline">Start upload your file here.</h3><br>
					
					<div class="col-md-8 col-md-offset-2">
						<form class="form-inline" method="post" action="">
							<div class="input-group">
								<label class="input-group-btn">
									<span class="btn btn-danger">
										Browse&hellip; <input type="file" id="media" name="media" style="display: none;" required>
									</span>
								</label>
								<input type="text" class="form-control" size="24" readonly required>
							</div>
							<div class="input-group">
								<select name="kategori" class="form-control" required>
									<option value="">Select Category</option>
									<?php
									$kat = $conn->query("SELECT * FROM category ORDER BY name ASC");
									while($row_kat = $kat->fetch_assoc()){
										echo '<option value="'.$row_kat['id'].'">'.$row_kat['name'].'</option>';
									}
									?>
								</select>
							</div>
							<div class="input-group">
								<select name="folder" class="form-control" required>
									<option value="">Select Folder</option>
									<?php
									if(!empty($user_name)){
										echo '<option value="0">'.$user_name.'</option>';
									}
									?>
									
									<?php
									$fol = $conn->query("SELECT * FROM folder WHERE user_id='$user_id' ORDER BY folder_name ASC");
									while($row_fol = $fol->fetch_assoc()){
										echo '<option value="'.$row_fol['folder_id'].'-'.$row_fol['folder_name'].'">|--'.$row_fol['folder_name'].'</option>';
									}
									?>
								</select>
							</div>
							<div class="input-group">
								<input type="submit" class="btn btn-primary" value="Start upload">
							</div>
						</form>
						<br>
						<div class="progress" style="display:none">
							<div id="progressBar" class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
								<span class="sr-only">0%</span>
							</div>
						</div>
						<div class="msg alert alert-info text-left" style="display:none"></div>
						<?php
						if($_SESSION['admin'] || $_SESSION['user']){
							$sesi = 1;
						}else{
							$sesi = 0;
						}
						?>
						<input type="hidden" id="sesi" name="sesi" value="<?php echo $sesi; ?>">
					</div>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Content -->
    <div class="container">
        <?php
		if($row_show_recent_files['value'] == 1){
		?>
		<div class="row">
            <div class="col-sm-12 text-center">
                <h1>Recent files</h1>
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <div class="row text-center">
			<?php
			$f = $conn->query("SELECT files.*, users.username as user 
								FROM files, users 
								WHERE files.id_user=users.id
								ORDER BY files.id DESC LIMIT 6");
			if($f->num_rows){
				while($rf = $f->fetch_assoc()){
					echo '
					<div class="col-sm-2">
						<i class="fa fa-file fa-5x"></i>
						<p><a href="download.php?d='.alphaID($rf['id']).'"><b>'.substr($rf['file_name'],0,20).'...</b></a><br>
						By '.$rf['user'].'<br>
						Downloaded '.$rf['view'].'x</p>
					</div>
					';
				}
			}else{
				echo 'No files';
			}
			?>
        </div>
        <!-- /.row -->

        <hr>
		
		<?php
		}
		?>
		
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p><?php echo $row_footer['value']; ?></p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/upload.js"></script>
	<script>
	$(function() {
	  // We can attach the `fileselect` event to all file inputs on the page
	  $(document).on('change', ':file', function() {
		var input = $(this),
			numFiles = input.get(0).files ? input.get(0).files.length : 1,
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [numFiles, label]);
	  });

	  // We can watch for our custom `fileselect` event like this
	  $(document).ready( function() {
		  $(':file').on('fileselect', function(event, numFiles, label) {

			  var input = $(this).parents('.input-group').find(':text'),
				  log = numFiles > 1 ? numFiles + ' files selected' : label;

			  if( input.length ) {
				  input.val(log);
			  } else {
				  if( log ) alert(log);
			  }

		  });
	  });
	  
	});
	</script>
</body>

</html>
