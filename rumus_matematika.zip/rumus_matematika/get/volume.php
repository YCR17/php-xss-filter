
<?php
  } else if ($aksi == 'volume'){
?>
      <div class="text">VOLUME<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="kubus" name="volume_aksi">
<input type="submit" value="balok" name="volume_aksi">
</div>
<div class="field">
<input type="submit" value="prisma_segitiga" name="volume_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>