
<?php
} else if($aksi == 'pl'){
?>
      <div class="text">PERSEKUTUAN LINGKARAN<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="pl_luar" name="pl_aksi">
</div>
<div class="field">
<input type="submit" value="pl_dalam" name="pl_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
