
<?php
}else if ($aksi == 'pytagoras') {
?>
      <div class="text">PYTAGORAS<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="garis_c" name="pytagoras_aksi">
</div>
<div class="field">
<input type="submit" value="garis_a_b" name="pytagoras_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
