
<?php
  }else if($aksi == 'luas_permukaan'){
?>
      <div class="text">LUAS PERMUKAAN<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="LP_kubus" name="LP_aksi">
</div>
<div class="field">
<input type="submit" value="LP_balok" name="LP_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
