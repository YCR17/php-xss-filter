<?php
  } else {
	?>
<!-- index -->
      <div class="text">DAFTAR<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="pytagoras" name="aksi">
</div>

<div class="field">
<input type="submit" value="volume" name="aksi">
</div>

<div class="field">
<input type="submit" value="luas_permukaan" name="aksi">
</div>

<div class="field">
<input type="submit" value="luas" name="aksi">
</div>

<div class="field">
  <input type="submit" value="keliling" name="aksi">
</div>
<div class="field">
  <input type="submit" value="kpk_fpb" name="aksi">
</div>
<div class="field">
  <input type="submit" value="pl" name="aksi">
</div>
<div class="link">
          click to
          <a href="?aksi=cari">search</a>
        </div>
</form>
<?php } ?>