
<?php 
for($i = 0; $i <= 10; $i++){
  echo "<br><font color='red'>$i</font><br>";
}
$i = scandir("p");
  print_r($i); 
  
  
  

foreach (glob("p/*/*.data.php") as $filename) { 

    include $filename; 
} 

?> 