<?php
$aksi = $_GET['aksi'];
if($aksi == 'cari'){

  header("Location: search_bar.html");

?>