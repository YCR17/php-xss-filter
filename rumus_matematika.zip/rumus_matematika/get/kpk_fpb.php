
<?php
  } else if($aksi == 'kpk_fpb'){
?>
      <div class="text">KPK & FPB<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="kpk_fpb" name="kpk_fpb_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
