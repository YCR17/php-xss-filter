<?php
include('config.php');
if(!$_SESSION['user']){
	header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $row_brand['value']; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="<?php echo $row_favicon['value']; ?>">
    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">
	
	<style>
	body {
		background: #e9ebee;
	}
	.body {
		background: #ffffff;
		border:1px solid #dfe0e4;
		margin-top: 50px;
		max-width: 900px;
	}
	</style>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo $row_brand['note']; ?>"><?php echo $row_brand['value']; ?></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<?php include('includes/menu.php'); ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    
    <!-- Page Content -->
    <div class="container body">
        <div class="row">
            <div class="col-sm-12">
				<h1>My Account</h1>
				<hr>
				<?php
				$user = $conn->query("SELECT * FROM users WHERE id='$id_user'");
				$row_user = $user->fetch_assoc();
				?>
				
				<div class="row">
					<div class="col-md-6">
						<h3>Profile</h3>
						<table class="table">
							<tr>
								<th width="100">Reg. date</th>
								<td width="10">:</td>
								<td><?php echo $row_user['reg_date']; ?></td>
							</tr>
							<tr>
								<th>Full name</th>
								<td>:</td>
								<td><?php echo $row_user['full_name']; ?></td>
							</tr>
							<tr>
								<th>Email</th>
								<td>:</td>
								<td><?php echo $row_user['email']; ?></td>
							</tr>
							<tr>
								<th>Username</th>
								<td>:</td>
								<td><?php echo $row_user['username']; ?></td>
							</tr>
							<tr>
								<th>Level</th>
								<td>:</td>
								<td><?php if($row_user['level'] == 1){ echo 'Administrator'; }else{ echo 'Standart user'; } ?></td>
							</tr>
						</table>
						<p><a href="account-edit.php" class="btn btn-primary">Edit account</a></p>
					</div>
					<div class="col-md-6">
						<h3>Change password</h3>
						
						<?php
						if($_POST['change']){
							$old = md5($_POST['old']);
							$new = $_POST['new'];
							$confirm = $_POST['confirm'];
							
							$cek = $conn->query("SELECT password FROM users WHERE id='$id_user'");
							$row_cek = $cek->fetch_assoc();
							if($old == $row_cek['password']){
								if($new == $confirm){
									if(strlen($new) >= 5){
										$p = md5($new);
										$up = $conn->query("UPDATE users SET password='$p' WHERE id='$id_user'");
										if($up){
											echo '<div class="alert alert-success">Success, please! log out and login again.</div>';
										}else{
											echo '<div class="alert alert-danger">Failed.</div>';
										}
									}else{
										echo '<div class="alert alert-danger">New password minimal 5 character.</div>';
									}
								}else{
									echo '<div class="alert alert-danger">Invalid confirm password.</div>';
								}
							}else{
								echo '<div class="alert alert-danger">Invalid current password.</div>';
							}							
						}
						?>
						
						<form method="post" action="">
							<div class="form-group">
								<input type="password" name="old" class="form-control" placeholder="Current password" required />
							</div>
							<div class="form-group">
								<input type="password" name="new" class="form-control" placeholder="New password" required />
							</div>
							<div class="form-group">
								<input type="password" name="confirm" class="form-control" placeholder="Confirm new password" required />
							</div>
							<div class="form-group">
								<input type="submit" name="change" class="btn btn-primary" value="Change password" />
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
        <!-- /.row -->
    </div>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>

</html>
