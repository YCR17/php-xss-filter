<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();

if(isset($_SESSION['admin_id'])){
	$id_user = $_SESSION['admin_id'];
}elseif(isset($_SESSION['user_id'])){
	$id_user = $_SESSION['user_id'];
}else{
	$id_user = '0';
}

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'ycr17_rm';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_errno) {
    echo die("Failed to connect to MySQL: " . $conn->connect_error);
}

//setting url website
$base_url = 'http://localhost:1111/rumus_matematika/';

//menampilkan nama brand
$config = $conn->query("SELECT * FROM config WHERE config='web_brand'");
$row_brand = $config->fetch_assoc();

//menampilkan favicon
$config = $conn->query("SELECT * FROM config WHERE config='favicon'");
$row_favicon = $config->fetch_assoc();

//menampilkan footer
$config = $conn->query("SELECT * FROM config WHERE config='footer'");
$row_footer = $config->fetch_assoc();


//fungsi konversi size
function bytesToSize($bytes, $precision = 2){  
  $kilobyte = 1024;
  $megabyte = $kilobyte * 1024;
  $gigabyte = $megabyte * 1024;
  $terabyte = $gigabyte * 1024;
 
  if (($bytes >= 0) && ($bytes < $kilobyte)) {
    return $bytes . ' B';
  } elseif (($bytes >= $kilobyte) && ($bytes < $megabyte)) {
    return round($bytes / $kilobyte, $precision) . ' KB';
  } elseif (($bytes >= $megabyte) && ($bytes < $gigabyte)) {
    return round($bytes / $megabyte, $precision) . ' MB';
  } elseif (($bytes >= $gigabyte) && ($bytes < $terabyte)) {
    return round($bytes / $gigabyte, $precision) . ' GB';
  } elseif ($bytes >= $terabyte) {
    return round($bytes / $terabyte, $precision) . ' TB';
  } else {
    return $bytes . ' B';
  }
}

//fungsi encrypt id
function alphaID($in, $to_num = false, $pad_up = false, $pass_key = null)
{
  $out   =   '';
  $index = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $base  = strlen($index);

  if ($pass_key !== null) {

    for ($n = 0; $n < strlen($index); $n++) {
      $i[] = substr($index, $n, 1);
    }

    $pass_hash = hash('sha256',$pass_key);
    $pass_hash = (strlen($pass_hash) < strlen($index) ? hash('sha512', $pass_key) : $pass_hash);

    for ($n = 0; $n < strlen($index); $n++) {
      $p[] =  substr($pass_hash, $n, 1);
    }

    array_multisort($p, SORT_DESC, $i);
    $index = implode($i);
  }

  if ($to_num) {
    $len = strlen($in) - 1;

    for ($t = $len; $t >= 0; $t--) {
      $bcp = bcpow($base, $len - $t);
      $out = $out + strpos($index, substr($in, $t, 1)) * $bcp;
    }

    if (is_numeric($pad_up)) {
      $pad_up--;

      if ($pad_up > 0) {
        $out -= pow($base, $pad_up);
      }
    }
  } else {
    if (is_numeric($pad_up)) {
      $pad_up--;

      if ($pad_up > 0) {
        $in += pow($base, $pad_up);
      }
    }

    for ($t = ($in != 0 ? floor(log($in, $base)) : 0); $t >= 0; $t--) {
      $bcp = bcpow($base, $t);
      $a   = floor($in / $bcp) % $base;
      $out = $out . substr($index, $a, 1);
      $in  = $in - ($a * $bcp);
    }
  }

  return $out;
}
?>