
<!DOCTYPE html>
<html>
<head>
<title>Selamat datang</title>
</head>
<body>
 <center>
<h2>SELAMAT DATANG KAWAN , ANDA SUDAH BERHASIL LOGIN....</h2>
<body style="margin:25px;">
<form action="inputdata.php" method="post">
Masukkan Jumlah Data : <input type="text" name="jumlah_lajur" size="2" />
<input type="submit" />
</form>
<br/>
 <a href="logout.php">Logout</a>
</center>
</body>
</html>