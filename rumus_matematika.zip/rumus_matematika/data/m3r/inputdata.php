<html>
<head>
<title>Isi Bilangan</title>
</head>
<body>
<div align="center">
<h2>Silahkan Isi Bilangan</h2>
 <body style="margin:25px;">
    <form action="proses.php" method="post">
<?php
    $jumlah_lajur = $_POST["jumlah_lajur"];
    for($i=0; $i<$jumlah_lajur; $i++){
?>
    Data ke <?php echo $i+1; ?> = <input type="text" name="lajur_ke_<?php echo $i; ?>" size="2" /><br /><br />
<?php
    }
?>
    <input type="hidden" value="<?php echo $jumlah_lajur; ?>" name="jumlah_lajur" />
    <input type="submit" />
    </form>
</div>
</body>
</html>