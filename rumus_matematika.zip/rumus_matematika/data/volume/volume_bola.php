<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
    <!-- <title>Glowing Inputs Login Form UI</title> -->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div class="login-form">
      <div class="text">
VOLUME<br>bola</div>
<form action="" method="get">
<div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder="jari jari" name="jari2">
        </div>
 <div class="field">
          <div class="fas fa-number">
</div>
<input type="text" placeholder="satuan (cm/m dll.)" name="satuan">
        </div>
<button>HITUNG</button>
        <div class="link">
          cari volume balok?
          <a href="volume_balok.php">klik disini</a>
        </div>
</form>
<?php
if( $_GET["jari2"] || $_GET["tinggi"] ) {
  $jari2 = $_GET['jari2'];
	$phi = 22/7;
	$r1 = 4/3 * ($phi * $jari2 * $jari2 * $jari2);
	$satuan = htmlentities($_GET["satuan"]);
  echo " <div class='text-hasil'>hasil volume kerucut adalah : <br> $r1 $satuan ² </div>";
}
?>
</div>
</body>
</html>
