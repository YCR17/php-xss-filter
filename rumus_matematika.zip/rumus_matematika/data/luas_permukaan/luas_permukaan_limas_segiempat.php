<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
    <!-- <title>Glowing Inputs Login Form UI</title> -->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div class="login-form">
      <div class="text">
LUAS PERMUKAAN<br>limas segiempat</div>
<form action="" method="get">
<div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder=" lebar alas" name="l_a">
        </div>
        <div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder="panjang alas" name="p_a">
        </div>
<div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder="tinggi limas" name="t_l">
        </div>
<div class="field">
  <div class="fas fa-number">
    </div>
    <input type="number" placeholder="panjang sisi" name="p_s">
</div>
 <div class="field">
          <div class="fas fa-number">
</div>
<input type="text" placeholder="satuan (cm/m dll.)" name="satuan">
        </div>
<button>HITUNG</button>
        <div class="link">
          cari volume balok?
          <a href="volume_balok.php">klik disini</a>
        </div>
</form>
<?php
if( $_GET["l_a"] || $_GET["p_a"] || $_GET["t_l"] || $_GET["p_s"]) {
  
  if($_GET["l_a"] == $_GET["p_a"]){
  $r1 = (($_GET["l_a"] * $_GET["p_a"]) + (4 * (1/2) * $_GET["p_a"] * $_GET["p_s"]));
  $r2 = "satu";
    
  } else{
  $r1 = (($_GET["l_a"] * $_GET["p_a"]) + (2 * (1/2) * $_GET["l_a"] * $_GET["p_s"]) + (2 * (1/2) * $_GET["p_a"] * $_GET["p_s"]));
  $r2 = "dua";
    
  }
  
  $satuan = htmlentities($_GET["satuan"]);
  echo " <div class='text-hasil'>hasil luas permukaan limas segiempat adalah : <br> $r1 $satuan ³ $r2</div>";
}
?>
</div>
</body>
</html>
