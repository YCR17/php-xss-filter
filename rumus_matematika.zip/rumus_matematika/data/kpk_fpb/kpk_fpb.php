<html> 
<head> 
<title>Algorithma FPB dan KPK</title> 
<link rel="stylesheet" href="../css/style.css">
</head> 
<body> 
<div class="login-form">
  <div class="text">KPK FPB<br>math tools</div><br>
  <div class="field">
  <input type="text" name="angka" id="inputa" value="" placeholder="pisah dengan koma 12,20,40"/>
  <input type="submit" value="Submit" onclick="Masukkan()"/> </div>
  <br>
<div class="text-hasil" id="hasil"></div> 
<div class="link">click to <a href="../">home</a></div>
</div>
<script src="kpk_fpb.js"></script>
</body> 
</html> 