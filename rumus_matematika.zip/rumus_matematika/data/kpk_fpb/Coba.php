<?php
function gcf($a, $b) { 
  return ( $b == 0 ) ? ($a):( gcf($b, $a % $b) ); 
}
function lcm($a, $b) { 
  return ( $a / gcf($a,$b) ) * $b; 
}

echo "1. KPK dari 12 dan 20 adalah ".lcm(12,20,50)."<br/>";
echo "2. FPB dari 12 dan 20 adalah ".gcf(12,20,50)."<br/>";
// kpk = icm || fpb = gcf
?>