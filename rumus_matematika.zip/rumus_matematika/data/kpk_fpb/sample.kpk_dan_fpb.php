<?php
//untuk menentukan FPB 2 bilangan maka panggil fungsi gcf(angka1, angka2);
function gcf($a, $b) { 
  return ( $b == 0 ) ? ($a):( gcf($b, $a % $b) ); 
}
//untuk menentukan KPK 2 bilangan maka panggil fungsi lcm(angka1, angka2);
function lcm($a, $b) { 
  return ( $a / gcf($a,$b) ) * $b; 
}
echo "Soal Nomor 1-3. <br/>";
//SOAL NOMOR 1 KPK dari 20 dan 12
echo "1. KPK dari 12 dan 20 adalah ".lcm(12,20)."<br/>";
//SOAL NOMOR 2 FPB dari 20 dan 12
echo "2. FPB dari 12 dan 20 adalah ".gcf(12,20)."<br/>";
//SOAL NOMOR 3 KPK dari 15 dan 25
echo "3. FPB dari 15 dan 25 adalah ".gcf(15,25)."<br/>";
?>
 
<!-- 
  samain persepsi dulu.
    - php itu gak bisa nampilin UI
    - sekalipun bisa dia butuh markup language, biasanya HTML
 -->
 <!-- 
  misalkan hasil perhitungan akan ditampilkan dibawah ini, maka berikut ini sintaksnya
  perhatikan ada tag php didalamnya
  -->
 
<!-- mulai tag php -->
<?php
  // cek dulu apakah ada variabel aksi, kenapa aksi? lihat action pada tag form
  // karena variabel aksi tertampil di url maka variabel ini dapat didapat dengan sintaks $_GET['index']
  if (isset($_GET['aksi'])) {
    // kemudian masukkan ke variabel, alasannya? jane sih ben luwih gampang, males ngetik dowo
    $aksi = $_GET['aksi'] ;

    // disini bisa pakai switch bisa juga pakai if, aku lebih suka kamu, eh switch
    switch ($aksi) {
      case 'hitung':
        // disini kan belum dapat data dari form nya nih, ambil dulu dengan sintaks $_POST['index']
        // index itu didapat dari atribut name tiap input, ini alasannya kenapa name harus berbeda
        // jangan lupa masukkin ke variabel juga
        $pertama = $_POST['angka_pertama'];
        $kedua   = $_POST['angka_kedua'];

        // nah disini baru panggil fungsi kpk sama fpb diatas, trus masukkin ke variabel
        // untuk kpk
        $hasil_kpk = lcm($pertama, $kedua);
        $hasil_fpb = gcf($pertama, $kedua);

        // sebenarnya bisa langsung ditampilin disini, atau dimana aja.
        // kan udah dimasukkin ke variabel
        // misal kalo disini
        echo 'Hasil KPK (ditampilkan didalam tag php) : ' . $hasil_kpk;
        echo '<br />';
        echo 'Hasil FPB (ditampilkan didalam tag php) : ' . $hasil_fpb;
        break;
      
      // default itu digunakan kalo aksi yang dimasukkan ngaco
      default:
        echo 'Masih dalam tahap pengembangan...';
        break;
    }
  }
?>
<!-- akhir tag php -->
   
 <!-- buat tampilan form nya dulu -->
 <html>
 <head>
  <title>KPK dan FPB</title>
 </head>
 <body>
  <!--
    action = kemana hasil masukkan ini akan dibawa
    method = memakai metode apa, ada 2
      post = tidak ditampilkan di url
      get = ditampilkan di url
   -->
  <form action="?aksi=hitung" method="post">
    <!-- 
      kalau angka bagusnya pakai type="number"
      name tiap input HARUS BERBEDA
      
      edited :
      tambahin value yang isinya variabel $pertama dan $kedua
    -->
    <input type="text" name="angka_pertama" value="<?php echo isset($pertama) ? $pertama : ''; ?>"> <br/>
    <input type="text" name="angka_kedua" value="<?php echo isset($kedua) ? $kedua : ''; ?>"> <br/>
    <input type="submit" value="Hitung">
  </form>
 
   <!-- garis horizontal -->
   <hr/>
   <!-- bisa juga ditampilkan di tag html -->
   Hasil KPK = <?php echo isset($hasil_kpk) ? $hasil_kpk : 'Silakan lakukan penghitungan terlebih dahulu...'; ?>
   <br/>
   Hasil FPB = <?php echo isset($hasil_fpb) ? $hasil_fpb : 'Silakan lakukan penghitungan terlebih dahulu...'; ?>
 
   <!-- 
    sebenarnya itu merupakan tag simple dari if
    if(isset($hasil_kpk)) {
      echo $hasil_kpk;
    } else {
      echo $hasil_fpb;
    }
 
    kenapa di cek dulu, karena menghindari error pas program pertama dibuka, kan variabel $hasil_kpk dan $hasil_fpb masih kosong
    -->
 </body>
 </html>