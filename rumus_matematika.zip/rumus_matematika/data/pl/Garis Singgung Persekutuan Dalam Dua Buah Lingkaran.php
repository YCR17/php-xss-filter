<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
    <!-- <title>Glowing Inputs Login Form UI</title> -->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div class="login-form">
      <div class="text">
PERSEKUTUAN LINGKARAN<br>dalam</div>
<form action="" method="get">
        <div class="field">
          <div class="fas fa-math">
</div>
<input type="number" placeholder="D" name="d">
        </div>
<div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder="R1" name="r1">
        </div>
 <div class="field">
   <div class="fas fa-number">
    
   </div>
<input type="number" placeholder="R2" name="r2">
 </div>
 <div class="field">
          <div class="fas fa-number">
</div>
<input type="text" placeholder="satuan (cm/m dll.)" name="satuan">
        </div>
<button>HITUNG</button>
        <div class="link">
          mau cari garis a/b ?
          <a href="pytagoras_a_b.php">klik disini</a>
        </div>
        <br>
        <div class="text-hasil">rumus :</div>
        <div class="field">
          <center>
            <div><div style="margin: 5px;">
<div class="smallfont" ><input value="CLICK TO SHOW"  onclick="if (this.parentNode.parentNode.getElementsByTagName('div')[1].getElementsByTagName('div')[0].style.display != '') { this.parentNode.parentNode.getElementsByTagName('div')[1].getElementsByTagName('div')[0].style.display = ''; this.innerText = ''; this.value = 'Hide'; } else { this.parentNode.parentNode.getElementsByTagName('div')[1].getElementsByTagName('div')[0].style.display = 'none'; this.innerText = ''; this.value = 'CLICK TO SHOW'; }" type="button"/>
</div>
<div class="alt2">
<div style="display: none;">
 <img src="../img/zzz3.png">
 <img src="../img/zzz4.png">
</div></div></div></div>
         
          </center>
        </div>
</form>
<?php
if( $_GET["d"] || $_GET["r1"] || $_GET["r2"] ) {
  $r1 = $_GET["r1"] + $_GET["r2"];
  $r2 = pow($r1,2);
  $d = pow($_GET["d"],2);
  $dahlah = $d - $r2;
  $rt = sqrt($dahlah);
  $satuan = htmlentities($_GET["satuan"]);
  echo "<br> <div class='text-hasil'>hasil Garis Singgung Persekutuan Dalam Dua Buah Lingkaran adalah : <br>$rt $satuan</div>";
}
?>
</div>
</body>
</html>



