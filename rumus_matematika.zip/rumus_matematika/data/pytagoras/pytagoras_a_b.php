<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
    <!-- <title>Glowing Inputs Login Form UI</title> -->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div class="login-form">
      <div class="text">
PYTAGORAS<br>garis a/b</div>
<form action="" method="get">
        <div class="field">
          <div class="fas fa-math">
</div>
<input type="number" placeholder="Garis a/b" name="a_b">
        </div>
<div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder="garis miring" name="c">
        </div>
        
 <div class="field">
          <div class="fas fa-number">
</div>
<input type="text" placeholder="satuan (cm/m dll.)" name="satuan">
        </div>
<button>HITUNG</button>
        <div class="link">
          mau cari garis miring ?
          <a href="pytagoras_c.php">klik disini</a>
        </div>
</form>
<?php
if( $_GET["a_b"] || $_GET["c"] ) {
  $r1 = pow($_GET["c"],2);
  $r2 = pow($_GET["a_b"],2);
  $r3 = $r1 - $r2;
  $r4 = sqrt($r3);
  $satuan = htmlentities($_GET["satuan"]);
  echo "<br> <div class='text-hasil'>hasil garis yang lain adalah : <br>$r4 $satuan</div>";
}
?>
</div>
</body>
</html>



