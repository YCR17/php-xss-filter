<!DOCTYPE html>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
    <!-- <title>Glowing Inputs Login Form UI</title> -->
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div class="login-form">
      <div class="text">
PYTAGORAS<br>garis miring</div>
<form action="" method="get">
        <div class="field">
          <div class="fas fa-math">
</div>
<input type="number" placeholder="Garis A" name="a">
        </div>
<div class="field">
          <div class="fas fa-number">
</div>
<input type="number" placeholder="Garis B" name="b">
        </div>
        
 <div class="field">
          <div class="fas fa-number">
</div>
<input type="text" placeholder="satuan (cm/m dll.)" name="satuan">
        </div>
<button>HITUNG</button>
        <div class="link">
          mau cari garis a/b ?
          <a href="pytagoras_a_b.php">klik disini</a>
        </div>
</form>
<?php
if( $_GET["a"] || $_GET["b"] ) {
  $r1 = pow($_GET["a"],2);
  $r2 = pow($_GET["b"],2);
  $r3 = $r1 + $r2;
  $r4 = sqrt($r3);
  $satuan = htmlentities($_GET["satuan"]);
  echo "<br> <div class='text-hasil'>hasil garis miring adalah : <br>$r4 $satuan</div>";
}
?>
</div>
</body>
</html>



