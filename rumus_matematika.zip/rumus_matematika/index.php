<!-- cek session -->
<?php include('includes/session.php'); ?>


<? include('ip.php') ?>
<? include('log2.php') ?>
<!-- Created By CodingNepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
    <!-- <title>Glowing Inputs Login Form UI</title> -->
        <title><?php echo $row_brand['value']; ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="<?php echo $row_favicon['value']; ?>">
    <!-- Custom CSS -->
    <link href="css/business-frontpage.css" rel="stylesheet">
    
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    
    
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    
  </head>
  <body>
  <? include('toast.html'); ?>
  
    
    <div class="login-form">







<?php
$aksi = $_GET['aksi'];
if($aksi == 'cari'){

  header("Location: search_bar.html")
?>
<?php
}else if ($aksi == 'pytagoras') {
?>
      <div class="text">PYTAGORAS<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="garis_c" name="pytagoras_aksi">
</div>
<div class="field">
<input type="submit" value="garis_a_b" name="pytagoras_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
<?php
  } else if ($aksi == 'volume'){
?>
      <div class="text">VOLUME<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="kubus" name="volume_aksi">
<input type="submit" value="balok" name="volume_aksi">
</div>
<div class="field">
<input type="submit" value="prisma_segitiga" name="volume_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
<?php
  }else if($aksi == 'luas_permukaan'){
?>
      <div class="text">LUAS PERMUKAAN<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="LP_kubus" name="LP_aksi">
</div>
<div class="field">
<input type="submit" value="LP_balok" name="LP_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
<?php
  }else if($aksi == 'luas'){
?>
      <div class="text">LUAS<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="L_lingkaran" name="luas_aksi">
</div>
<div class="field">
<input type="submit" value="more" name="luas_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
<?php
  } else if($aksi == 'keliling'){
?>
      <div class="text">KELILING<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="keliling_lingkaran" name="keliling_aksi">
</div>
<div class="field">
<input type="submit" value="more" name="keliling_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
<?php
  } else if($aksi == 'kpk_fpb'){
?>
      <div class="text">KPK & FPB<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="kpk_fpb" name="kpk_fpb_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
<?php
} else if($aksi == 'pl'){
?>
      <div class="text">PERSEKUTUAN LINGKARAN<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="pl_luar" name="pl_aksi">
</div>
<div class="field">
<input type="submit" value="pl_dalam" name="pl_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>







<?php
  } else {
	?>
<!-- index -->
      <div class="text">DAFTAR<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="pytagoras" name="aksi">
</div>

<div class="field">
<input type="submit" value="volume" name="aksi">
</div>

<div class="field">
<input type="submit" value="luas_permukaan" name="aksi">
</div>

<div class="field">
<input type="submit" value="luas" name="aksi">
</div>

<div class="field">
  <input type="submit" value="keliling" name="aksi">
</div>
<div class="field">
  <input type="submit" value="kpk_fpb" name="aksi">
</div>
<div class="field">
  <input type="submit" value="pl" name="aksi">
</div>
<div class="link">
          click to
          <a href="?aksi=cari">search</a>
        </div>
</form>
<?php } ?>
<br><br>
 <div class="text-hasil">
   <?php echo $row_footer['value']; ?>
   </div>
   
   
   
   <br>
   	<?php
	if($_SESSION['admin']){
?>
<p><a href="admin-account.php" class="btn btn-primary">Dashboard</a></p>
<?php } else if($_SESSION['user']){
?>
<p><a href="account.php" class="btn btn-primary">Dashboard</a></p>
<?}?>



</div>
</body>
</html>
<?php
$pytagoras = $_GET['pytagoras_aksi'];
$volume = $_GET['volume_aksi'];
$luas_permukaan = $_GET['LP_aksi'];
$luas = $_GET['luas_aksi'];
$keliling = $_GET['keliling_aksi'];
$kpk_fpb = $_GET["kpk_fpb_aksi"];
$pl = $_GET["pl_aksi"];

/*if else pytagoras*/
	if ($pytagoras == 'garis_a_b') {
	  header("Location: data/pytagoras/pytagoras_a_b.php");
	} else if($pytagoras == 'garis_c') {
	  header("Location: data/pytagoras/pytagoras_c.php");
	}
/*if else volume*/
  if($volume == 'kubus'){
    header("Location: data/volume/volume_kubus.php");
  }else if($volume == 'balok'){
    header("Location: data/volume/volume_balok.php");
  }else if($volume == 'prisma_segitiga'){
    header("Location: data/volume/volume_prisma_segitiga.php");
  }
/*if else luas permukaan*/
if($luas_permukaan == 'LP_kubus'){
  header("Location: data/luas_permukaan/luas_permukaan_kubus.php");
}else if($luas_permukaan == 'LP_balok'){
  header("Location: data/luas_permukaan/luas_permukaan_balok.php");
}
/*if else luas*/
if ($luas == 'L_lingkaran'){
  header("Location: data/luas/luas_lingkaran.php");
}
/*if else keliling*/
if ($keliling == 'keliling_lingkaran'){
  header("Location: data/keliling/keliling_lingkaran.php");
}
/*if else kpk_fpb*/
if ($kpk_fpb == 'kpk_fpb'){
  header("Location: data/kpk_fpb/kpk_fpb.php");
}
/*if else persekutuan lingkaran*/
if ($pl == 'pl_luar'){
  header("Location: data/pl/Garis Singgung Persekutuan Luar Dua Buah Lingkaran.php");
} else if($pl == 'pl_dalam'){
  header("Location: data/pl/Garis Singgung Persekutuan Dalam Dua Buah Lingkaran.php");
}
	?>