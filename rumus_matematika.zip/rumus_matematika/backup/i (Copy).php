<pytagoras>
<?php
}else if ($aksi == 'pytagoras') {
?>
      <div class="text">PYTAGORAS<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="garis_c" name="pytagoras_aksi">
</div>
<div class="field">
<input type="submit" value="garis_a_b" name="pytagoras_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</pytagoras>


<volume>
<?php
  } else if ($aksi == 'volume'){
?>
      <div class="text">VOLUME<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="kubus" name="volume_aksi">
<input type="submit" value="balok" name="volume_aksi">
</div>
<div class="field">
<input type="submit" value="prisma_segitiga" name="volume_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</volume>


<luas_permukaan>
<?php
  }else if($aksi == 'luas_permukaan'){
?>
      <div class="text">LUAS PERMUKAAN<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="LP_kubus" name="LP_aksi">
</div>
<div class="field">
<input type="submit" value="LP_balok" name="LP_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</luas_permukaan>


<luas>
<?php
  }else if($aksi == 'luas'){
?>
      <div class="text">LUAS<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="L_lingkaran" name="luas_aksi">
</div>
<div class="field">
<input type="submit" value="more" name="luas_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</luas>


<keliling>
<?php
  } else if($aksi == 'keliling'){
?>
      <div class="text">KELILING<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="keliling_lingkaran" name="keliling_aksi">
</div>
<div class="field">
<input type="submit" value="more" name="keliling_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</keliling>


<kpk_fpb>
<?php
  } else if($aksi == 'kpk_fpb'){
?>
      <div class="text">KPK & FPB<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="kpk_fpb" name="kpk_fpb_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</kpk_fpb>


<persekutuan_lingkaran>
<?php
} else if($aksi == 'pl'){
?>
      <div class="text">PERSEKUTUAN LINGKARAN<br>tools math</div>
<form action="" method="get">

<div class="field">

<input type="submit" value="pl_luar" name="pl_aksi">
</div>
<div class="field">
<input type="submit" value="pl_dalam" name="pl_aksi">
</div>
        
         <div class="link">
          back to
          <a href="index.php">home</a>
        </div>
</form>
</persekutuan_lingkaran>