<?php include('config.php');
if(!$_SESSION['is_login']){

	header("Location: login.php");

} 
?>