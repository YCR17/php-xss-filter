<?php
if($_SESSION['admin']){
	if($row_show_categories['value'] == 1){
		$c = $conn->query("SELECT * FROM category ORDER BY name ASC");
		if($c->num_rows){
			echo '<ul class="nav navbar-nav">';
			while($rc = $c->fetch_assoc()){
				echo '<li><a href="category.php?d='.alphaID($rc['id']).'">'.$rc['name'].'</a></li>';
			}
			echo '</ul>	';
		}
	}
	echo '
	<ul class="nav navbar-nav navbar-right">
		<li>
			<a href="index.php">Home</a>
		</li>
		<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>
			<ul class="dropdown-menu">
				<li>

					<a href="admin-users.php">Users</a>

				</li>
				<li>
					<a href="admin-account.php">Account</a>
				</li>
				<li>
					<a href="admin-setting.php">Setting</a>
				</li>
				

				<li>
					<a href="logout.php" onclick="return confirm(\'Are you sure?\')">Sign Out</a>
				</li>
			</ul>
		</li>
		<p class="navbar-text">Hi, '.$_SESSION['admin'].'</p>
	</ul>
	';
}elseif($_SESSION['user']){
	if($row_show_categories['value'] == 1){
		$c = $conn->query("SELECT * FROM category ORDER BY name ASC");
		if($c->num_rows){
			echo '<ul class="nav navbar-nav">';
			while($rc = $c->fetch_assoc()){
				echo '<li><a href="category.php?d='.alphaID($rc['id']).'">'.$rc['name'].'</a></li>';
			}
			echo '</ul>	';
		}
	}
	echo '
	<ul class="nav navbar-nav navbar-right">
		<li>
			<a href="index.php">Home</a>
		</li>
		<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>
			<ul class="dropdown-menu">
				<li>
					<a href="account.php">Account</a>
				</li>
				

				<li>
					<a href="logout.php" onclick="return confirm(\'Are you sure?\')">Sign Out</a>
				</li>
			</ul>
		</li>
		<p class="navbar-text">Hi, '.$_SESSION['user'].'</p>
	</ul>
	';
}else{
	if($row_show_categories['value'] == 1){
		$c = $conn->query("SELECT * FROM category ORDER BY name ASC");
		if($c->num_rows){
			echo '<ul class="nav navbar-nav">';
			while($rc = $c->fetch_assoc()){
				echo '<li><a href="category.php?d='.alphaID($rc['id']).'">'.$rc['name'].'</a></li>';
			}
			echo '</ul>	';
		}
	}
	echo '
	<ul class="nav navbar-nav navbar-right">
		<li>
			<a href="register.php">Register</a>
		</li>
		<li>
			<a href="login.php">Sign In</a>
		</li>
	</ul>
	';
}
?>